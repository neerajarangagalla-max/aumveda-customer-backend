"""Admin vendor schemas."""
